import mariadb from "mariadb";
import dotenv from "dotenv";

dotenv.config();

const data = mariadb.createPool({
    host: process.env.URL_BD,
    user: process.env.USER_BD,
    password: process.env.USER_PASSWORD,
    database: process.env.DATABASE,
    connectionLimit: 20,
    acquireTimeout: 20000,
    idleTimeout: 30000,
    resetAfterUse: true,
    minimumIdle: 5
});

async function testConnection() {
    try {
        const connection = await data.getConnection();
        console.log("Conexión exitosa a la base de datos.");
        connection.release();
    } catch (error) {
        console.error("Error al conectar con la base de datos:", error);
    }
}
testConnection();

export default data;
