import nodemailer from 'nodemailer'
import dotenv from 'dotenv'
dotenv.config()
const config = () => {
    return{
        service: "gmail",
        secure: true,
        auth:{
            user : process.env.CORREO,
            pass : process.env.CORREO_PASSWORD,
        }
    }
}

export const transporter = nodemailer.createTransport(config())