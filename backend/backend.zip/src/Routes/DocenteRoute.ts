import { Router } from "express";
import { authenticate } from "../Middleware/auth";
import { DocentesControllers } from "../controllers/DocenteControllers";
import multer from "multer";

const storage = multer.memoryStorage();
const upload = multer({ storage });

const router = Router();

router.use(authenticate);

// GET - Obtener todos los docentes
router.get(
    '/GetDocente',
    DocentesControllers.GetDocenteControllers
);

// GET - Obtener un docente por ID
router.get(
    '/GetDocente/:id',
    DocentesControllers.GetDocenteByIdControllers
);

// GET - Obtener habilidades de un docente
router.get(
    '/habilidades/:id',
    DocentesControllers.gethabilidadesDocentes
);

// POST - Crear nuevo docente
router.post(
    '/AddDocentes',
    upload.fields([
        { name: 'img', maxCount: 1 },
        { name: 'cv', maxCount: 1 },
    ]),
    DocentesControllers.AddDocentesControllers
);

// PUT - Actualizar docente
router.put(
    '/UpdateDocente/:id',
    upload.fields([
        { name: 'img', maxCount: 1 },
        { name: 'cv', maxCount: 1 },
    ]),
    DocentesControllers.UpdateDocenteControllers
);

// DELETE - Eliminar docente (soft delete)
router.delete(
    '/DeleteDocentes/:id',
    DocentesControllers.DeleteDocenteControllers
);

export default router;