import fs from 'fs';
import path from 'path';
import sharp from 'sharp'; 

export async function uploadImageGlobal(file: Express.Multer.File, id: string, fecha: string, ruta:string) {
  const folderPath = `./Uploads/img/${ruta}/${id}-${fecha}`;

  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath, { recursive: true });
  }

  const allowedExtensions = ['.jpg', '.jpeg', '.png'];
  const extension = path.extname(file.originalname).toLowerCase();

  if (!allowedExtensions.includes(extension)) {
    throw new Error(`Formato inválido para ${file.originalname}. Solo JPG, JPEG y PNG permitidos.`);
  }

  if (file.size > 5 * 1024 * 1024) {
    throw new Error(`La imagen ${file.originalname} debe pesar máximo 5MB`);
  }

  const fileName = `${id}-${fecha}${extension}`;
  const savePath = path.join(folderPath, fileName);

  try {
    const image = sharp(file.buffer);

    if (extension === '.png') {
      await image
        .png({ quality: 50, compressionLevel: 9 }) // optimiza PNG
        .toFile(savePath);
    } else {
      await image
        .jpeg({ quality: 50 }) // optimiza JPG/JPEG
        .toFile(savePath);
    }

    return savePath;
  } catch (error) {
    console.error('Error al optimizar la imagen:', error);
    throw new Error('Error al optimizar la imagen.');
  }
}

