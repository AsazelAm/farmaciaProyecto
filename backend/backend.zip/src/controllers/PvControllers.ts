import { Request, Response } from "express";
import DataPv from "../Models/PvModels";
import { uploadImageGlobal } from "../Middleware/SaveImg";
import { GetDateToday } from "../lib/Time";


export class PvControllers {
    static readonly  GetAllPvControllers = async(req:Request,res:Response)=>{
        try {
            const data = await DataPv.PvAll();
            res.status(200).json(data)
        } catch (error) {
            console.error("Error al obtener propuestas  de valor:", error);
            res.status(500).json({ error: "Error al obtener propuestas  de valor:" });
        }
    }

    static readonly AddPv = async(req:Request,res:Response)=>{
        try {
            const files = req.files as { [fieldname: string]: Express.Multer.File[] };
            // CORRECCIÓN: array1 viene en req.body como string JSON
            const array1Data = JSON.parse(req.body.array1);
            const {nombre, identificador} = array1Data[0];
            const LogoFile = files['logo'] ? files['logo'][0] : null;
            const BannerFile = files['banner'] ? files['banner'][0] : null;
            const CuadroFile = files['cuadro'] ? files['cuadro'][0] : null;
            const ModalFile = files['modal'] ? files['modal'][0] : null;
            console.log(ModalFile)
            const data =  await DataPv.AddPv(nombre,identificador)
            const now = GetDateToday();

            if(LogoFile){
                const ruta = await uploadImageGlobal(LogoFile,String(data),now,'LogoPv')
                await DataPv.UpdateImgAddpv(ruta,data);
            }
            if(BannerFile){
                const ruta = await uploadImageGlobal(BannerFile, String(data), now, 'BannersPv')
                await DataPv.UpdatebannerAddpv(ruta,data)
            }
            if(ModalFile){
                const ruta = await uploadImageGlobal(ModalFile, String(data), now, 'ModalsPv')
                await DataPv.UpdatemodalAddpv(ruta,data)
            }
            if(CuadroFile){
                const ruta = await uploadImageGlobal(CuadroFile, String(data), now, 'CuadroPv')
                await DataPv.UpdateCuadroAddpv(ruta,data)
            }
            res.status(200).json('Propuesta de valor creado correctamente')

        } catch (error) {
            console.error("Error al agregar propuestas de valor:", error);
            res.status(500).json({ error: "Error al agregar propuestas de valor:" });
        }
    }

    static readonly deletePv = async (req:Request,res:Response)=>{
        try {
            const {id} = req.params
            const data = await DataPv.DeletePv(id);
            res.status(200).json(data)
        } catch (error) {
            console.error("Error al eliminar propuesta de valor:", error);
            res.status(500).json({ error: "Error al eliminar propuesta de valor:" });
        }
    }

    static readonly UpdatePvControllers = async(req:Request,res:Response)=>{
        try {
            const {id} = req.params;
            const files = req.files as { [fieldname: string]: Express.Multer.File[] };
            
            const array1Data = JSON.parse(req.body.array1);
            const {nombre, identificador} = array1Data[0];
            
            const LogoFile = files['logo']?.[0] || null;
            const BannerFile = files['banner']?.[0] || null;
            const CuadroFile = files['cuadro']?.[0] || null;
            const ModalFile = files['modal']?.[0] || null;
            
            await DataPv.UpdatePvModels(nombre, identificador, id);
            const now = GetDateToday();

            if(LogoFile){
                const ruta = await uploadImageGlobal(LogoFile, id, now, 'LogoPv')
                await DataPv.UpdateImgAddpv(ruta, id);
            }
            if(BannerFile){
                const ruta = await uploadImageGlobal(BannerFile, id, now, 'BannersPv')
                await DataPv.UpdatebannerAddpv(ruta, id)
            }
            if(ModalFile){
                const ruta = await uploadImageGlobal(ModalFile, id, now, 'ModalsPv')
                await DataPv.UpdatemodalAddpv(ruta, id)
            }
            if(CuadroFile){
                const ruta = await uploadImageGlobal(CuadroFile, id, now, 'CuadroPv')
                await DataPv.UpdateCuadroAddpv(ruta, id)
            }
            
            res.status(200).json('Propuesta de valor actualizada correctamente')
        } catch (error) {
            console.error("Error al actualizar propuesta de valor:", error);
            res.status(500).json({ error: "Error al actualizar propuesta de valor:" });
        }
    }

     static readonly  GetPvCalendario = async(req:Request,res:Response)=>{
        try {
            const data = await DataPv.PvCalendario();
            res.status(200).json(data)
        } catch (error) {
            console.error("Error al obtener propuestas  de valor:", error);
            res.status(500).json({ error: "Error al obtener propuestas  de valor:" });
        }
    }

    static readonly UpdatePvEstaController=async(req:Request,res:Response)=>{
        try{
            const {id}=req.params;
            const{Status}=req.body;
            const data=await DataPv.UpdatePvEstaModels(Status,id);
            res.status(200).json(data);
        }catch(error){
            console.log("Erro actualizar Status,",error);
            res.status(500).json({error:"Erro actualizar Status de PV"});
        }
    }

}