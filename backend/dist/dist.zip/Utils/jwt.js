"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateJwt = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const GenerateJwt = (id) => {
    const token = jsonwebtoken_1.default.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    return token;
};
exports.GenerateJwt = GenerateJwt;
//# sourceMappingURL=jwt.js.map